#include "stdafx.h"
#include "PostFilmGrain.h"

PostFilmGrain::PostFilmGrain() :
	PostProcessingMaterial(L"Effects/Post/FilmGrain.fx")
{
}


