//Resharper Disable All

	#include "stdafx.h"
	#include "PostGrayscale.h"

	PostGrayscale::PostGrayscale():
		PostProcessingMaterial(L"Effects/Post/Grayscale.fx")
	{
	}


