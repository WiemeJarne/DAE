#include "stdafx.h"
//Prevents Warning LNK4221 > Caused by empty source files in a Library
__declspec(dllexport) void getRidOfLNK4221_Material() {}